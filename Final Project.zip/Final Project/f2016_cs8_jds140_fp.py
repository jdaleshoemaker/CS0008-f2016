# name       : John Dale Shoemaker
# email      : jds140@pitt.edu
# class      : CS0008-f2016
# instructor : Max Novelli (man8@pitt.edu)
#First things first, I had to define the three classes set out in the assignment. Here I define them as name, distance and runs.
class participant:
    name = "unknown"
    distance = 0
    runs = 0
    #With the classes defined, I then narrowed each one down with more specific definitions
    def __init__(self, name, distance=0):
        # setting the name
        self.name = name
        # setting the distance if non zero
        if distance > 0:
            # setting the distance
            self.distance = distance
            # setting the number of runs accordingly
            self.runs = 1;
        # end of the if statement
    #This is the end of defining the constructor

    def __eq__(self, other):
        return self.name == other.name;

    def __ne__(self, other):
        return not self.__eq__(other);

    def __hash__(self):
        return hash(self.name);

    def __lt__(self, other):
        return self.name < other.name

    # addDistance method
    def addDistance(self, distance):
        if distance > 0:
            self.distance += distance
            self.runs += 1
        # end if
    # end def addDistance

    # addDistances method
    def addDistances(self, distances):
        # loops over list
        for distance in distances:
            if distance > 0:
                self.distance += distance
                self.runs += 1
            # end if
        # end for
    # end def addDistance

    # return the name of the participant
    def getName(self):
        return self.name
    # end def getName

    # return the total distance run computed
    def getDistance(self):
        return self.distance
    # end def getDistance

    # return the number of runs
    def getRuns(self):
        return self.runs
    # end def getRuns

    # stringify the object
    def __str__(self):
        return \
            "Name : " + format(self.name, '>20s') + \
            ". Distance run : " + format(self.distance, '9.4f') + \
            ". Runs : " + format(self.runs, '4d')
    # end def __init__

    # convert to csv
    def tocsv(self):
        return ','.join([self.name, str(self.runs), str(self.distance)])
    # end def tocsv
#With the classes and methods defined and described above, I'm now going to establish a directory that will run through and sort the data that I need to evaluate
directory = 'C:\\Users\\Dale\\PycharmProjects\\finalproject\\';
#Here I define the masterfile, while points to the file that contains the three data sets I need
masterFile = input("Please provide master file : ")
#If the masterfile is the one that I think it is, that is, the one with the three data sets, this try and except bit will read all of the data and strip the blank space off of the end of each line.
try:
    dataFiles = [file.rstrip('\n') for file in open(masterFile,'r')]
except:
    print("Impossible to read master file or invalid file name")
    exit(1)
#This next part is going to sort through the entire dataset by the participants names. Once it parses each line, it's going to beging to compare each participant by the distance he or she ran.
#make empty list
participants = [];
for dataFile in dataFiles:
    for dataLine in open(dataFile, 'r'):
        if "name" in dataLine:
            continue;
            #skip

        parsed = dataLine.rstrip('\n').split(',');

        try:
            currParticipant = participant(parsed[0].strip(), float(parsed[1]));
            if currParticipant in participants:
                participants[participants.index(currParticipant)].addDistance(currParticipant.getDistance())
            else:
                participants.append(currParticipant);
        except:
            print("Error reading line in: " + dataFile);
        #end if
    #end for
#end for
#Here I define processData and use the methods from above to employ it
processedData = [(participant.getName(), participant.getDistance(), participant.getRuns()) for participant in participants]
#Here is where we take the parsed data and comparisons from above and use them to locate specifically which participant ran the greatest distance, the total distance and the other calucations we need.
numFiles = len(dataFiles);
numLines = sum([runs for (name, dist, runs) in processedData]);

totalDistance = sum([dist for (name, dist, runs) in processedData]);
(minDist, minName) = min([(dist, name) for (name, dist, runs) in processedData]);
(maxDist, maxName) = max([(dist, name) for (name, dist, runs) in processedData]);

numParticipants = len(participants);
numMultParticipants = sum([runs > 1 for (name, dist, runs) in processedData]);
#defining the parameters for the print layout
INTEGER = '5d'
FLOAT = '12.5f'
STRING = '20s'
#printing out the results of the program using the parameters defined above.
print("")
print(" Number of Input files read   : " + format(numFiles,INTEGER))
print(" Total number of lines read   : " + format(numLines,INTEGER))
print("")
print(" Total distance run           : " + format(totalDistance,FLOAT))
print("")
print(" Max distance run             : " + format(maxDist,FLOAT))
print("   by participant             : " + format(maxName,STRING))
print("")
print(" Min distance run             : " + format(minDist,FLOAT))
print("   by participant             : " + format(minName,STRING))
print("")
print(" Total number of participants : " + format(numParticipants,INTEGER))
print(" Number of participants")
print("  with multiple records       : " + format(numMultParticipants,FLOAT))
print("")
#writing the output file
outputFile = 'f2016_cs8_jds_fp.output.csv'
fh = open(outputFile,'w')
fh.write('name,records,distance\n')
for participant in sorted(participants):
    fh.write(participant.tocsv() + '\n')
fh.close()