#name       : John Dale Shoemaker
# email      : jds140@pitt.edu
# class      : CS0008-f2016
# instructor : Max Novelli (man8@pitt.edu)

import os.path

format_key_length = 30

#First I defined the first required function, the printKV function. This function will accept key and value arguments and an optional klen argument
def printKV(key,value,klen = 0):
    klen = max(klen,len(key));
    if isinstance(value, str):
        fvalue = '30s'
    elif (value, float):
        fvalue = '10.3f'
    elif (value, int):
        fvalue = '10d'
    else:
        value = str(value)
        fvalue = '20s'
    print(format(key, '>' + str(klen) + 's'), ' : ', format(value, fvalue))
#Must now define the second required function, the processFile function. This function will all the program to read each line of the given file and separate them into two fields, names and distances and then list the partial totals from each run.
def processFile(fh):
    partial_total_distance = 0
    partial_total_numberlines = 0
    for line in fh:
            # This first command in the for loop tells the program to take each line in the file and split it where it sees a comma. #In this particular file, that split comes between the names and distance fields.
            # This command is taking the space off of the end of the line and separting names and distances into two separate things.
            [name, distance] = line.rstrip('\n').split(',')
            # Here I am cleaning the distance part of the split.
            distance = float(distance)
            #Here I employ the printKV function defined above to display the name and distance of the first run through of the file
            printKV('Name', name, format_key_length)
            printKV('Distance', distance, format_key_length)
            #updating the partial totals here
            partial_total_distance += distance
            partial_total_numberlines += 1
            return [partial_total_distance, partial_total_numberlines]
#defining the totals here
total_distance = 0
total_numberlines = 0
number_files = 0
#This is the first thing the user will see when the file runs
print('Please enter the name of the first file:')
file = input('File name: ')
#Here we tell the program to open the file the user has entered, quit if certain information is entered but otherwise run through the first iteration of the file an then close.
while (file != '' and file != 'quit' and file != 'q' and os.path.exists(file) ):
    fh = open(file, 'r')
    partial_total_numberlines, partial_total_distance = processFile(fh)
    fh.close()
#After running through the file, we print the preliminary results here
    print('')
    printKV('Here are the partial names found: ', partial_total_numberlines, format_key_length)
    printKV('Here are the partial distances found: ', partial_total_distance, format_key_length)
    print('')
#establishing relationship between total and partial distances.
    number_files += 1
    total_distance += partial_total_distance
    total_numberlines += partial_total_numberlines
#the last thing the user sees
    print('Please enter the name of the next file to process. Enter quit or q to exit.')
    file = input('File name: ')
#print the final report
    print('')
    printKV('Here are the total names found: ', total_numberlines, format_key_length)
    printKV('Here are the total distances found: ', total_distance, format_key_length)
    print('')